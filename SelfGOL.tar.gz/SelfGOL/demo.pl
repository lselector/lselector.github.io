#! /usr/local/bin/perl -w

for (1..10)
{
	print "$_: ", $_**2, "\n";
}
